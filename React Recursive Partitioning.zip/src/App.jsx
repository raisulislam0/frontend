import React, { useCallback, useReducer } from "react";

// Utility functions
const generateId = (() => {
  let id = 0;
  return () => ++id;
})();

const generateColor = () => `hsl(${Math.random() * 360}, 70%, 80%)`;

// Configuration constants
const CONFIG = {
  MIN_PARTITION_SIZE: 10,
  SNAP_POINTS: [25, 50, 75],
  SNAP_THRESHOLD: 5,
};

// Layout reducer to manage complex state transitions
const layoutReducer = (state, action) => {
  switch (action.type) {
    case "SPLIT_PARTITION": {
      const { id, direction } = action.payload;

      const splitNode = (node) => {
        if (node.id === id && node.children.length === 0) {
          return {
            ...node,
            direction,
            children: [
              {
                id: generateId(),
                direction: null,
                color: node.color,
                children: [],
                size: 50,
              },
              {
                id: generateId(),
                direction: null,
                color: generateColor(),
                children: [],
                size: 50,
              },
            ],
          };
        }

        return node.children.length > 0
          ? {
              ...node,
              children: node.children.map(splitNode),
            }
          : node;
      };

      return splitNode(state);
    }

    case "MERGE_PARTITION": {
      const { id } = action.payload;

      const mergeNode = (node) => {
        if (node.children.some((child) => child.id === id)) {
          const mergingChild = node.children.find((child) => child.id === id);
          return {
            ...node,
            children: [],
            direction: null,
            color: mergingChild.color,
          };
        }

        return node.children.length > 0
          ? {
              ...node,
              children: node.children.map(mergeNode),
            }
          : node;
      };

      return mergeNode(state);
    }

    case "RESIZE_PARTITION": {
      const { id, newSize, shouldSnap } = action.payload;

      const resizeNode = (node) => {
        if (node.id === id) {
          const { MIN_PARTITION_SIZE } = CONFIG;
          const constrainedSize = Math.max(
            MIN_PARTITION_SIZE,
            Math.min(100 - MIN_PARTITION_SIZE, newSize)
          );

          return {
            ...node,
            size: shouldSnap
              ? snapToNearestQuarter(constrainedSize)
              : constrainedSize,
          };
        }

        return node.children.length > 0
          ? {
              ...node,
              children: node.children.map(resizeNode),
            }
          : node;
      };

      return resizeNode(state);
    }

    default:
      return state;
  }
};

// Snap to nearest quarter utility
const snapToNearestQuarter = (size) => {
  const { SNAP_POINTS, SNAP_THRESHOLD } = CONFIG;
  const nearestPoint = SNAP_POINTS.reduce(
    (closest, point) =>
      Math.abs(point - size) < Math.abs(closest - size) ? point : closest,
    100
  );

  return Math.abs(size - nearestPoint) <= SNAP_THRESHOLD ? nearestPoint : size;
};

const Partition = ({ data, dispatch, isRoot = false }) => {
  const { id, direction, color, children } = data;

  const handleResize = useCallback(
    (event, childIndex, initialSize, startPos, shouldSnap = false) => {
      const container =
        event.target.parentNode.parentNode.getBoundingClientRect();
      const isVertical = direction === "vertical";

      const currentPos = isVertical ? event.clientX : event.clientY;
      const containerSize = isVertical ? container.width : container.height;
      const deltaPercent = ((currentPos - startPos) / containerSize) * 100;

      const newSize = initialSize + deltaPercent;

      // Dispatch resize for both children
      dispatch({
        type: "RESIZE_PARTITION",
        payload: {
          id: children[childIndex].id,
          newSize,
          shouldSnap,
        },
      });
      dispatch({
        type: "RESIZE_PARTITION",
        payload: {
          id: children[1 - childIndex].id,
          newSize: 100 - newSize,
          shouldSnap,
        },
      });
    },
    [children, direction, dispatch]
  );

  const startResize = useCallback(
    (event, childIndex) => {
      event.preventDefault();
      const initialSize = children[childIndex].size;
      const startPos = direction === "vertical" ? event.clientX : event.clientY;

      const handleMouseMove = (e) => {
        handleResize(e, childIndex, initialSize, startPos, false);
      };

      const handleMouseUp = (e) => {
        handleResize(e, childIndex, initialSize, startPos, true);

        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
        document.body.style.cursor = "";
      };

      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor =
        direction === "vertical" ? "col-resize" : "row-resize";
    },
    [children, direction, handleResize]
  );

  // Leaf node (no children)
  if (children.length === 0) {
    return (
      <div
        className="flex flex-col justify-center items-center w-full h-full"
        style={{ backgroundColor: color }}
      >
        <div className="flex">
          <button
            onClick={() =>
              dispatch({
                type: "SPLIT_PARTITION",
                payload: { id, direction: "vertical" },
              })
            }
            className="px-1 py-0.5 bg-white text-black border black"
          >
            v
          </button>
          <button
            onClick={() =>
              dispatch({
                type: "SPLIT_PARTITION",
                payload: { id, direction: "horizontal" },
              })
            }
            className="px-1 py-0.5 bg-white text-black border black"
          >
            h
          </button>
          {!isRoot && (
            <button
              onClick={() =>
                dispatch({
                  type: "MERGE_PARTITION",
                  payload: { id },
                })
              }
              className="px-1 py-0.5 bg-red-500 text-white"
            >
              -
            </button>
          )}
        </div>
      </div>
    );
  }

  // Partitioned layout
  return (
    <div
      className={`flex ${
        direction === "vertical" ? "flex-row" : "flex-col"
      } w-full h-full`}
    >
      {children.map((child, index) => (
        <div
          key={child.id}
          className="relative flex-none"
          style={{
            flexBasis: `${child.size}%`,
            minWidth: 0,
            minHeight: 0,
          }}
        >
          <Partition data={child} dispatch={dispatch} isRoot={false} />
          {index !== children.length - 1 && (
            <>
              <div
                className={`absolute ${
                  direction === "vertical"
                    ? "right-0 top-0 h-full border-r-2"
                    : "bottom-0 left-0 w-full border-b-2"
                } border-black`}
              />
              <div
                className={`absolute ${
                  direction === "vertical"
                    ? "right-[-4px] top-0 h-full w-2 cursor-col-resize"
                    : "bottom-[-4px] left-0 w-full h-2 cursor-row-resize"
                } bg-transparent z-10`}
                onMouseDown={(e) => startResize(e, index)}
              />
            </>
          )}
        </div>
      ))}
    </div>
  );
};

const App = () => {
  const [layout, dispatch] = useReducer(layoutReducer, {
    id: generateId(),
    direction: null,
    color: generateColor(),
    children: [],
    size: 100,
  });

  return (
    <div className="h-screen w-screen overflow-hidden border-2 border-black">
      <Partition data={layout} dispatch={dispatch} isRoot={true} />
    </div>
  );
};

export default App;
